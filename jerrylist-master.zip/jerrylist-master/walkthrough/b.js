module.exports = function (name) {
	console.log("Hello " + name);
}