# 2017-05-20 upload

application url: https://flpportal-i042416trial.dispatcher.hanatrial.ondemand.com/sites?siteId=6af9e0d2-8b95-413c-9dc5-7d8b0c8b0ec1#Shell-home

I find it from Chrome history :(

# 2017-12-08 5:47PM

* node local.js, then http://localhost:3000/ui5/